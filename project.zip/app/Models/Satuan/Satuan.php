<?php

namespace App\Models\Satuan;

use Illuminate\Database\Eloquent\Model;

class Satuan extends Model
{
    protected $table = 'satuan';

    protected $guarded = ['id_satuan'];
}
