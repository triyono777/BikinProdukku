<?php

namespace App\Models\Kontak;

use Illuminate\Database\Eloquent\Model;

class Kontak extends Model
{
    protected $table = 'kontak';

    protected $guarded = ['id_kontak'];
}
