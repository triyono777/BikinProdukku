<?php

namespace App\Http\Controllers\Pengguna;

use App\Http\Controllers\Controller;
use App\Models\Pengguna\Pengguna;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class PenggunaController extends Controller
{
    public function penggunaView($username, $id_user) {
        $pengguna = Pengguna::select(['id_user'])->with('transaksi')->where('id_user', $id_user)->get()->toArray();
        // dd($pengguna);
    	return view('admin.pengguna.index', compact('pengguna'));
    }

    // public function penggunaTransaksiData($username, $id_user) {
    // 	$pengguna = Pengguna::with('transaksi')->where('id_user', $id_user)->get()->toArray();

    // 	$datatables = DataTables::of($pengguna)
    //         ->editColumn('gambar_bukti', function($data) {
    //             return '<img src="/bukti_pembayaran/'.$data['gambar_bukti'].'" width="100" height="80"/>';
    //         })
    //         ->editColumn('status', function($data) {
    //             return '<span class="btn btn-'.$data['status'] == 1 ? "success" : "danger".'">'.$data['status'] == 1 ? 'Success' : 'Pending'.'</span>';
    //         })
    //         ->rawColumn(['gambar_bukti'])
	   //      ->addIndexColumn();

	   //  return $datatables->make(true);
    // }

}
