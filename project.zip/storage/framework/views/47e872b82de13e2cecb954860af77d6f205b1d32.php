<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Notifikasi Transaksi</h3>
			<div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
				</button>
				<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
			</div>
		</div>
		<div class="box-body">
			<div class="row">
				<div class="col-md-12">
					<div class="table-responsive">
						<table id="datatables" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>No</th>
									<th>Notifikasi</th>
									<th>Action</th>
								</tr>
							</thead>

						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customJs'); ?>
<script type="text/javascript">
	$('#datatables').DataTable({
	        processing: true,
	        serverSide: true,
	        ajax: '<?php echo e(route('admin.landingPageData')); ?>',
	        columns: [
	            {data: 'DT_Row_Index', orderable: false, searchable: false},
	            {data: 'notifikasi'},
	            {data: 'action'},
	        ]
	 });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>