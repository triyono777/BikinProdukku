<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<div class="box">
		<div class="box-header">
			<h4 class="page-header">
			Data Transaksi
			</h4>
		</div>
		<div class="box-body">
			<div class="collapse" id="collapse-tambah" style="margin-top: 10px">
				<div class="well">
					<form action="" method="post" id="frm-tambah">
						<div class="form-group">
							<label for="">Nama Satuan</label>
							<input type="text" name="nama_satuan" class="form-control">
						</div>
						<div class="form-group">
							<label for="">Berat</label>
							<input type="text" name="berat" class="form-control">
						</div>
						<button class="btn btn-primary">Tambah</button>
					</form>
				</div>
			</div>
			<div class="table-responsive" style="margin-top: 15px;">
				<table id="datatables" class="table table-bordered table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Bukti Pembayaran</th>
							<th>Kode Invoice</th>
							<th>Tgl</th>
							<th>Total Pembayaran</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $pengguna[0]['transaksi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e(++$key); ?></td>
								<td><img src="/bukti_pembayaran/<?php echo e($value['gambar_bukti']); ?>"></td>
								<td><?php echo e($value['kode_invoice']); ?></td>
								<td><?php echo e(date('d-F-Y', strtotime($value['tanggal']))); ?></td>
								<td><?php echo e('Rp. '.number_format($value['total'])); ?></td>
								<td>
									<span class="btn btn-xs btn-<?php echo e($value['status'] == 1 ? "success" : "danger"); ?>"><?php echo e($value['status'] == 1 ? 'Success' : 'Pending'); ?></span>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>