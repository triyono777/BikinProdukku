<?php if(Session::has('danger')): ?>
	<div class="alert alert-danger">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<strong><?php echo e(Session::get('danger')); ?></strong>
	</div>
<?php endif; ?>