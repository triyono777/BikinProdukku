<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('node_modules/html5-device-mockups/dist/device-mockups.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('node_modules/croppie/croppie.css')); ?>">
    </head>
    <body>
        <section>
                <div class="col-md-4">
                    <div class="device-wrapper">
                      <div class="device" data-device="iPhone5" data-orientation="portrait" data-color="black">
                        <div class="screen">

                        </div>
                        <div class="button">

                        </div>
                      </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <form enctype="multipart/form-data" method="post" action="<?php echo e(route('uploadImage')); ?>">
                        <div class="form-group">
                            <label>Upload</label>
                            <input type="file" name="file" id="file" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
        </section>

        <div class="modal fade" id="modal-edit">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Modal title</h4>
                    </div>
                    <div class="modal-body">
                        <img src="" id="image">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>

        <script src="//code.jquery.com/jquery.js"></script>
        <!-- Latest compiled and minified JS -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
        <script src="<?php echo e(URL::to('node_modules/croppie/croppie.min.js')); ?>"></script>
        <script type="text/javascript">
            function readUrl(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        var img = $('#image');
                        img.attr('src', e.target.result);
                        // var h = img.height;
                        //   var w = img.width;
                        img.load(function() {
                            var w = this.width;
                            var h = this.height;

                            $('#image').croppie({
                                viewport: {
                                      width: 270,
                                      height: 650,
                                      type: 'square' //default 'square'
                                  },
                                  boundary: {
                                      width: w,
                                      height: h
                                  },
                                  enableZoom: true, //default true // previously showZoom
                                  showZoomer: false, //default true
                                  mouseWheelZoom: true //default true
                            });
                        })


                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }


            $('#file').change(function() {
                $('#modal-edit').modal('show');
                readUrl(this);
            })
        </script>
    </body>
</html>
