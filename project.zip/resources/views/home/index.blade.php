@extends('home.templates.app')

@section('content')

@endsection