@extends('admin.templates.app')
@section('content')
<div class="col-md-12">
	<div class="box">
		<div class="box-header">
			<h4 class="page-header">
			Data Transaksi
			</h4>
		</div>
		<div class="box-body">
			<div class="table-responsive" style="margin-top: 15px;">
				<table id="datatables" class="table table-bordered table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Bukti Pembayaran</th>
							<th>Kode Invoice</th>
							<th>Tgl</th>
							<th>Total Pembayaran</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
						@foreach($pengguna[0]['transaksi'] as $key => $value)
							<tr>
								<td>{{++$key}}</td>
								<td><img src="/bukti_pembayaran/{{$value['gambar_bukti']}}"></td>
								<td>{{$value['kode_invoice']}}</td>
								<td>{{date('d-F-Y', strtotime($value['tanggal']))}}</td>
								<td>{{'Rp. '.number_format($value['total'])}}</td>
								<td>
									<span class="btn btn-xs btn-{{$value['status'] == 1 ? "success" : "danger"}}">{{$value['status'] == 1 ? 'Finished' : 'Pending'}}</span>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
@endsection